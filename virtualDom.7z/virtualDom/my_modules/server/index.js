const $static = require('node-static');
const $extension = require('./nodeStatic_extension');

const $static_server = new $static.Server();

const static = {
  server(req, res) {
    $static_server.serve(req, res);
  }
};

Object.assign(static, $extension);

module.exports = static;