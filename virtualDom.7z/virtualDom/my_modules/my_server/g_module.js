
const $g_moudle = {};

$g_moudle['ejs'] = require('./ejs/index.js');
$g_moudle['tool'] = require('./tools.js');

module.exports = $g_moudle;