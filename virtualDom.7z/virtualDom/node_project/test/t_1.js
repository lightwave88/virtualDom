
(() => {
	'use strict';
	debugger;
	// Establish the root object, `window` (`self`) in the browser, `global`
	// on the server, or `this` in some virtual machines. We use `self`
	// instead of `window` for `WebWorker` support.
	let root = (typeof self == 'object' && self.self === self) ? self : null;

	

	if (root == null) {
		root = (typeof global == 'object' && global.global === global) ? global : null;
	}

	if (root == null) {
		root = Function('return this')() || {};
	}

	return root;
})();