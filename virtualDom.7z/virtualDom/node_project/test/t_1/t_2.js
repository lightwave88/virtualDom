


function getFun() {
  let count = 0;
  return function () {
    console.log(count++);
  };
}

let a = getFun();
let b = a;

console.log(a === b);

b = getFun();



(async () => {
  console.time('a');
  for (let i = 0, max = 100; i < max; i++) {
    console.log('%s => %s', i, a === b);
  }
  console.timeEnd('a');
})();


(async () => {

  console.time('b');
  for (let i = 0, max = 100; i < max; i++) {
    console.log('%s => %s', i, 1 === 1);
  }
  console.timeEnd('b');
})();
