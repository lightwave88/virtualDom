import $GM from '../g_module.js';

// 專門處理 tag.attr
import { general } from './attrs/general.js';
import { classList } from './attrs/classList.js';
import { style } from './attrs/style.js';

const $checkList = [classList, style];
const $general = general;

//------------------------------------------------------------------------------
// API
const $attr = {
  setVnodeAttr: setVnodeAttr,
  createDom: createDom,
  updateDom: updateDom,
};

export { $attr as attr };


//------------------------------------------------------------------------------
// vnode.attr 的設定方式
function setVnodeAttr(vnode, computer, attrName, attrValue) {
  debugger;

  if (computer == true) {
    vnode.compute_attrs.add(attrName);
  }
  let fn;

  $checkList.some(it => {
    debugger;
    if (it.isAttr(attrName) && it.isTag(vnode.tagName) && typeof it.setVnodeAttr == 'function') {
      // 找到特殊解
      fn = it.setVnodeAttr;
      return true;
    }
  });

  if (fn == null) {
    // 使用一般解
    fn = $general.setVnodeAttr;
  }
  debugger;
  fn(vnode, attrName, attrValue);
}
//------------------------------------------------------------------------------
function createDom(dom, vnode) {
  debugger;
  const attrs = vnode.attrs;

  const tagName = dom.tagName;

  attrs.forEach((v, k) => {
    debugger;
    let fn;
    $checkList.some(it => {
      if (it.isAttr(k) && it.isTag(tagName) && typeof it.createDom == 'function') {
        // 找到特殊解
        fn = it.createDom;
        return true;
      }
    });
    if (fn == null) {
      // 使用一般解
      fn = $general.createDom;
    }

    debugger;
    fn(dom, vnode, attrName);
  });

}
//------------------------------------------------------------------------------

function updateDom(dom, oldVnode, vnode, isStatic) {
  debugger;

  isStatic = !!isStatic;

  const $style = dom.style;
  const tagName = dom.tagName;
  const attrs = new Map(vnode.attrs);
  const compute_attrs = vnode.compute_attrs;

  if (isStatic) {
    // 保留舊有的
    // 更新計算屬性
    attrs.forEach((v, k) => {
      if (!compute_attrs.has(k)) {
        attrs.delete(k);
      }
    });
  } else {
    debugger;
    // 舊有的全不要
    const dom_attrs = Array.from(dom.attributes);
    dom_attrs.forEach(node => {
      let { nodeName: name } = node;

      if (!attrs.has(name)) {
        dom.removeAttribute(name);
      }
    });
  }
  //------------------

  attrs.forEach((v, k) => {
    let fn;
    $checkList.some(it => {
      if (it.isAttr(k) && it.isTag(tagName) && typeof it.updateDom == 'function') {
        // 找到特殊解
        fn = it.updateDom;
        return true
      }
    });
    if (fn == null) {
      // 使用一般解
      fn = $general.updateDom;
    }

    fn(dom, oldVnode, vnode, attrName);
  });
}

