'use strict';

import $GM from '../../g_module.js';
import { DomNode } from './domNode.js';

// <b-slot name="" b-script="">
class BSlotNode extends DomNode {

  name = 'BSlotNode';
  $scriptContent = '';

  // 變數對應
  $args = 'null';

  $reg_1 = /^\{([^]*)\}$/;
  $reg_2 = /\s*\:\s*/;

  slotID;
  slotName;
  //----------------------------------------------------------------------------
  constructor(config) {
    super(config);

    let dom = this.dom;

    if (this.parentIsKeepAll != null) {
      // keepAll 以下不能有動態結構
      throw new Error('slot position has problem');
    }

    if (!dom.hasAttribute('name')) {
      // 必須要有 id 方便未來的事件綁定
      throw new Error('<b-slot>...attr.name...');
    }
    this.slotName = dom.getAttribute('name').trim();

    if (dom.hasAttribute('b-script')) {
      // 要傳遞的 data
      this.$scriptContent = dom.getAttribute('b-script').trim();
    }

    if (this.$scriptContent.length != 0) {
      // 驗證 b-script 的內容
      if (!this.$reg_1.exec(script)) {
        throw new Error(`<b-slot> attr.b-script(${script}) type error`);
      }
      this.$args = this.$scriptContent;
    }
    // 與 slotEvent 有關
    // 重要
    // this.parent.addSlotChildID(this.slotID);
  }
  //----------------------------------------------------------------------------
  static getInstance(config) {
    return new BSlotNode(config);
  }
  //----------------------------------------------------------------------------
  getSelfCommand() {

    const sysConfig = $GM.get('sysConfig');

    const {
      var_root,
      var_parentNode,
      var_vnode,
      var_createVnode,
      var_sys,
    } = sysConfig.tempSysVarName;

    let lines = [];

    let slotID = JSON.stringify(this.slotID);
    let slotName = JSON.stringify(this.slotName);

    // fix here
    // fix here

    let command = `${var_sys}.callSlot(${slotID}, ${slotName}, ${this.$args})`;
    command = `${this._space()}${var_parentNode}.appendSlot(${command});\n`;

    lines.push(command);

    let res = lines.join('');

    return res;
  }
  //----------------------------------------------------------------------------

}

export { BSlotNode };
