'use strict';

import $GM from '../../g_module.js';
import { DomNode } from './domNode.js';

// const $reg_1 = /^#text$/i;

class TextNode extends DomNode {

  name = 'TextNode';
  text;
  textOutput;

  //----------------------------------------------------------------------------
  constructor(config) {
    super(config);

    const $util = $GM.get('util');

    // 重點
    // 重點
    // 不要落入比較字串耗時的步驟
    // this.isStatic = false;
    this.text = this.dom.nodeValue;

    if (this.nodeName == '#text' && this.contentIsEmpty()) {
      // 空文字節點
      this.isPrint = false;
    }

    let has_compute = $util.hasComputeVar(this.text);

    if (has_compute) {
      this.isStatic = false;
      this.textOutput = $util.SS(this.text);
    } else {
      this.textOutput = JSON.stringify(this.text);
    }
  }
  //----------------------------------------------------------------------------
  static getInstance(config) {
    let node = new TextNode(config);

    return node;
  }
  //----------------------------------------------------------------------------
  // @ override
  setStatic(value) {

  }
  //----------------------------------------------------------------------------
  getSelfCommand() {
    // debugger;

    if (!this.isPrint) {
      // 空文字節點
      return '';
    }
    //-------------
    const $util = $GM.get('util');
    const sysConfig = $GM.get('sysConfig');

    const {
      var_root,
      var_parentNode,
      var_vnode,
      var_createVnode,
    } = sysConfig.tempSysVarName;

    let lines = [];

    // createVnode
    lines.push(`${var_vnode} = ${var_createVnode}("${this.nodeName}", null, ${var_parentNode});\n`);

    lines.push(`// level(${this.level}), index(${this.index})\n`);


    let isStatic = new String(this.isStatic);

    // static
    lines.push(`${var_vnode}.setStatic(${isStatic});\n`);


    lines.push(`${var_vnode}.setText(${this.textOutput});\n`);

    lines.push(`${var_vnode}.end();\n`);

    lines = lines.map((l) => {
      // format
      return (this._space() + l);
    });

    return lines.join('');
  }
  //----------------------------------------------------------------------------
  clear() {
    super.clear();
  }
  //----------------------------------------------------------------------------
  // 特殊
  contentIsEmpty() {
    let val = this.text.trim();
    return (val.length < 1);
  }

}

export { TextNode };
