'use strict';

import $GM from './g_module.js';

// style
const $reg_1 = /^([^]*?):([^]*)/;
const CALLBACK_ID = '$vnodeEvent';

let $UID = 0;

class Vnode {

  // v_id;
  //------------------
  // 優化搜尋用的

  index = null;

  staticIndex = null;

  factoryId;

  level;
  //------------------

  // 與所映射的 dom.nodeName 相同
  nodeName = null;

  // 判別是否是 tag
  tagName = null;

  // 非標準標籤節點
  text;

  // 代表的 dom
  dom;
  //------------------
  // vnode
  parent = null;

  // 子節點(vnode)
  childs = [];
  //------------------

  // <b-slot> 的 parent
  // 一個 node 可以有多個 slot
  // {}
  slotEvents;
  //------------------
  keep;
  keepAll;
  //------------------

  // dom.attrs
  attrs = new Map();

  // 記錄是否有含計算的 attr
  compute_attrs = new Set();
  //------------------

  // 關於事件
  events = {};

  events_cb = {};
  //------------------

  isStatic;

  // 模板內的系統
  // keep, keepAll, slot 會用到
  tempSys;
  //----------------------------------------------------------------------------
  static create(nodeName, tagName, parent, sys) {
    return new Vnode(nodeName, tagName, parent, sys);
  }

  //----------------------------------------------------------------------------
  static getVnode(dom) {
    const VNODE_VARNAME = $GM.get('sysConfig').domVarname.vnode;

    if (dom.hasOwnProperty(VNODE_VARNAME)) {
      return dom[VNODE_VARNAME] || null;
    }
    return null;
  }
  //----------------------------------------------------------------------------
  static linkDom(dom, vnode) {
    const VNODE_VARNAME = $GM.get('sysConfig').domVarname.vnode;
    let oldVnode = null;

    if (!dom.hasOwnProperty(VNODE_VARNAME)) {
      Object.defineProperty(dom, VNODE_VARNAME, {
        configurable: true,
        writable: true,
        value: vnode,
      });
    } else {
      oldVnode = dom[VNODE_VARNAME] || null;

      if (oldVnode != null) {
        if (oldVnode.isEqual(vnode)) {
          return null;
        } else {
          // dom.vnode 轉移時，要清除事件綁定
          Vnode.unlinkDom(dom);
        }
      }
      dom[VNODE_VARNAME] = vnode;
    }

    vnode.dom = dom;

    return oldVnode;
  }
  //----------------------------------------------------------------------------
  static unlinkDom(dom) {
    const VNODE_VARNAME = $GM.get('sysConfig').domVarname.vnode;

    let oldVnode = dom[VNODE_VARNAME] || null;
    if (oldVnode == null) {
      return;
    }
    oldVnode.dom = null;
    // 清除綁定事件
    // oldVnode.removeEvent();

  }
  //----------------------------------------------------------------------------
  static is_vnode(obj) {
    if (obj == null || (typeof obj != 'object')) {
      return false;
    }
    return (obj instanceof Vnode);
  }
  //----------------------------------------------------------------------------
  static is_emptyNode(obj) {
    if (!(obj instanceof Vnode)) {
      throw new Error('...');
    }
    return (this.nodeName == null && this.tagName == null);
  }
  //----------------------------------------------------------------------------
  // 從 domNode 轉接資訊
  constructor(nodeName, tagName, parent = null, sys = null) {

    // this.v_id = $UID++;
    if (parent != null) {
      this.parent = parent;
    }

    if (sys == null) {
      // 空的 vnode
    } else {

      this.tempSys = sys;
      let factory = this.tempSys.getFactory();
      this.factoryId = factory.id;

      if (this.tempSys.$isSlot != null) {
        // 被 <b-slot> 套嵌
        // 特例
        this.isStatic = false;
      }
    }

    if (tagName != null) {
      this.tagName = tagName;
    }

    if (nodeName != null) {
      this.nodeName = nodeName;
    }
  }
  //----------------------------------------------------------------------------
  setStatic(judge) {
    if (this.isStatic == null) {
      this.isStatic = judge;
    }
  }
  //----------------------------------------------------------------------------
  appendTo(parent) {
    parent.append(this);
  }
  //----------------------------------------------------------------------------
  append(child) {
    // debugger;

    child = child || [];

    if (!Array.isArray(child)) {
      child = [child];
    }

    const childList = this.childs;

    child.forEach(el => {

      let index = childList.length;
      el.index = index;
      el.parent = this;
      childList.push(el);

      el._inheritParent(this);
    });

    // debugger;

    this._checkStaticChild();
  }
  //----------------------------------------------------------------------------
  // <b-slot>
  appendSlot(data) {
    // debugger;

    if (data == null) {
      return;
    }
    // 返回的數據
    // id: slotID
    // render: vnode
    // events: slotEvents
    let {
      id,
      render,
      events
    } = data;

    if (this.slotEvents == null) {
      this.slotEvents = {};
    }
    // 記錄事件
    this.slotEvents[id] = events;

    // 登錄，方便未來 slotEvents 綁定
    this.tempSys.registSlotParent(this);

    // 處理 vnode
    this.append(render);
  }
  //----------------------------------------------------------------------------
  // keep, keepAll 會用到
  removeChild(child) {

    let index = this.childs.findIndex(el => {
      if (el.isEqual(child)) {
        return true;
      }
    });

    if (index < 0) {
      return;
    }
    this.childs.splice(index, 1);

    child._unheritParent();

    let childDom = child.dom;

    if (childDom != null && childDom.parentNode) {
      childDom.parentNode.removeChild(childDom);
    }

    this._checkStaticChild();
  }
  //----------------------------------------------------------------------------
  // <b-slot> 會用到
  removeAllChild() {
    let childs = this.childs.slice();
    this.childs.length = 0;

    childs.forEach((child) => {

      child._unheritParent();

      let childDom = child.dom;
      if (childDom != null && childDom.parentNode) {
        childDom.parentNode.removeChild(childDom);
      }
    });
    return childs;
  }
  //----------------------------------------------------------------------------
  // computer:attr 是否由 data 所控制
  setAttr(computer = false, attrName, ...args) {
    // debugger;
    const $attr = $GM.get('attr');
    $attr.setVnodeAttr(this, computer, attrName, args);
  }
  //----------------------------------------------------------------------------
  // computer:文字內容 是否由 data 所控制
  setText(...args) {
    // debugger;

    args = args.map((arg) => {
      let res;
      if (typeof arg == 'string') {
        res = arg;
      } else if (arg == null) {
        res = '';
      } else if (typeof arg != 'string') {
        try {
          res = JSON.stringify(arg);
        } catch (er) {
          res = er.toString();
        }
      }
      return res;
    });
    this.text = args.join('');
  }
  //----------------------------------------------------------------------------
  linkDom(dom) {
    let oldVnode = Vnode.linkDom(dom, this);
    return oldVnode;
  }
  //----------------------------------------------------------------------------
  // 與 dom 脫鉤
  unlinkDom() {
    Vnode.unlinkDom(this.dom);
  }
  //----------------------------------------------------------------------------
  // 設定結束
  end() {

    // 檢查 static
    if (this.isStatic == null) {
      this.isStatic = true;
    }
    //------------------
    // keep
    if (this.keep != null) {
      // slot.keep 必須重命名
      this.tempSys.addKeep(this);
    }

    // keepAll
    if (this.keepAll != null) {
      // slot.keepAll 必須重命名      
      this.tempSys.addKeepAll(this);
    }
    //------------------
    if (this.parent != null) {
      // this.parent = parent;
      this.appendTo(this.parent);
    } else {
      this.level = 0;
    }
  }
  //----------------------------------------------------------------------------
  clearChilds() {
    this.childs.length = 0;
  }

  setKeep(name) {
    this.keep = name;
  }

  setKeepAll(name) {
    this.keepAll = name;
  }

  //----------------------------------------------------------------------------
  // 當 dom 易主時
  removeEvent(eventName = null, callback = null) {
    callback = (typeof callback == 'function') ? callback : null;
    eventName = eventName || null;

    if (callback != null && callback[CALLBACK_ID] == null) {
      return;
    }

    let keyList = [];

    if (eventName != null) {
      if (eventName in this.events) {
        keyList = [eventName];
      }
    } else {
      keyList = Object.keys(this.events);
    }

    keyList.forEach((name) => {

      if (callback == null) {
        this.events[name].length = 0;
      } else {

        let callbackList = this.events[name];
        let i = 0;
        while (i < callbackList.length) {
          let j = i++;
          let fn = callbackList[j]

          if (callback[CALLBACK_ID] === fn[CALLBACK_ID]) {
            callbackList.splice(j, 1);
            i = j;
          }
        }
      }

      if (this.events[name].length == 0) {
        delete this.events[name];
        if (!(name in this.events_cb)) {
          return;
        }
        let callback_1 = this.events_cb[name];
        delete this.events_cb[name];
        this.dom.removeEventListener(name, callback_1, {
          capture: true
        });
      }

    });
  }
  // dom 事件
  addEvent(eventName, callback) {
    if (!(eventName in this.events_cb)) {
      // 初始化
      this.events_cb[eventName] = this._getEventCallback(eventName);
      this.dom.addEventListener(this.events_cb[eventName], {
        capture: true
      });
      this.events[eventName] = [];
    }
    const eventList = this.events[eventName];

    if (callback[CALLBACK_ID] == null) {

    }

    eventList.push(callback);
  }
  //----------------------------------------------------------------------------
  getDom() {
    return this.dom || null;
  }
  //----------------------------------------------------------------------------
  isEqual(node) {

    if (!(node instanceof Vnode)) {
      return false;
    }

    return this === node;
  }
  //----------------------------------------------------------------------------
  // 釋放資源
  destroy() {
    debugger;

    return;

    if (this.dom == null) {
      // 空節點
      return;
    }

    if (this.dom.hasOwnProperty(VNODE_VARNAME)) {
      if (this.dom[VNODE_VARNAME] === this) {
        delete this.dom[VNODE_VARNAME];
      }
    }

    // this.detach(true);
    // this.parent = null;

    this.nodeName = null;
    this.tagName = null;
    this.text = null;
    this.id = null;

    this.classList.length = 0;
    this.classList = null;

    this.attrs.clear();
    this.attrs = null;

    for (var k in this.style) {
      delete this.style[k];
    }

    this.style = null;

    this.compute_attrs.clear();
    this.compute_attrs = null;

    // this.is_static = null;

    this.unlinkDom();

    console.log('vnode.destroy');
    console.dir(this);
  }
  //----------------------------------------------------------------------------
  // 繼承特性的檢查
  // 因應 <b-slot> 活動插入新的 vnode
  // 未決
  _inheritParent(parent) {
    this.level = parent.level + 1;
  }
  //----------------------------------------------------------------------------
  // 便於 dom 配對
  _checkStaticChild() {
    // debugger;
    let index = 0;

    this.childs.forEach(el => {
      if (el.isStatic) {
        el.staticIndex = index++;
      }
    });
  }
  //----------------------------------------------------------------------------
  _unheritParent() {
    child.parent = null;
    child.index = null;
    child.staticIndex = null;
    child.level = 0;
  }
  //----------------------------------------------------------------------------
  _getEventCallback(eventName) {

    const callback = function (e) {
      let eventList = this.events[eventName];
      let copy_eventList = eventList.slice();

      let i = 0;

      while (i < copy_eventList.length) {
        let j = i++;
        let fn = copy_eventList[j];

        // 避免某個事件 callback 突然被移除
        let is_include = eventList.some((_fn) => {
          if (_fn[CALLBACK_ID] === fn[CALLBACK_ID]) {
            return true;
          }
        });

        if (!is_include) {
          // 事件 callback 不在了
          return;
        }

        // context 未來要指定
        fn.call(null, e);
      }

    } // endFun

    return callback;
  }

}
//==============================================================================
export { Vnode };
