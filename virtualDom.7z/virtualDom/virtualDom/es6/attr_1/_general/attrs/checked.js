'use strict';

import $GM from '../../../g_module.js';


const checked = {
  attrName: 'style',
  isAttr_1: isAttr_1,
  setVnodeAttr: setVnodeAttr,
  isAttr_2: isAttr_2,
  initDom: initDom,
  updateDom: updateDom,
};

export { checked };