'use strict';

import { _general } from './attrs/_general.js';
import { className } from './attrs/className.js';
import { style } from './attrs/style.js';
import { selected } from './attrs/selected.js';

const $solutionList = [className, style, selected];
const $generalSolution = _general;
const $cache_1 = new Map();
const $cache_2 = new Map();


// 適用於一般 tag
const $general_tag = {
  attrMap: {},
  tagName: '*',
  // setVnodeAttr
  hasSolutuon_1(vnode, attrName) {
    // debugger;

    let solution = null;

    if ($cache_1[attrName] != null) {
      solution = $cache_1[attrName];
    } else {
      $solutionList.some(s => {
        // debugger;
        if (typeof (s.isAttr_1) == 'function') {
          let res = s.isAttr_1(vnode, attrName);

          if (res) {
            solution = s;
          }
          return res;
        }
      });

      debugger;
      if (solution == null) {
        // 採用通用解
        solution = $generalSolution;
      }
      $cache_1[attrName] = solution;
    }

    return solution;
  },
  // initDom, updateDom
  hasSolutuon_2(vnode, attrName) {
    // debugger;

    let solution = null;

    if ($cache_2[attrName] != null) {
      solution = $cache_2[attrName];
    } else {
      $solutionList.some(s => {
        // debugger;
        if (typeof (s.isAttr_2) == 'function') {
          let res = s.isAttr_2(vnode, attrName);
          if (res) {
            solution = s;
          }
          return res;
        }
      });

      if (solution == null) {
        // 採用通用解
        solution = $generalSolution;
      }
      $cache_2[attrName] = solution;
    }

    return solution;
  }
};

export { $general_tag as _general };
export default $general_tag;
//------------------------------------------------------------------------------


