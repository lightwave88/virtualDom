import $GM from './g_module.js';

class RenderJob {
  dom;
  template;
  view;
  context;
  events = {};
  data;

  constructor(dom) {
    this.setDom(dom);
  }
  //----------------------------------------------------------------------------
  setDom(dom) {
    if(dom == null){
      return;
    }
    
    if(typeof dom == 'string'){
      dom = document.querySelector(dom);
    }
    this.dom = dom;
  }

  getDom() {
    return this.dom;
  }
  //----------------------------------------------------------------------------
  setTemplate(temp) {
    this.template = temp;
  }

  getTemplate() {
    return this.template;
  }
  //----------------------------------------------------------------------------
  setView(view) {
    this.view = view;
  }

  getView() {
    return this.view;
  }
  //----------------------------------------------------------------------------
  setContext() {

  }  

  getContext() {
    return this.context;
  }
  //----------------------------------------------------------------------------
  setEvents() {

  }

  getEvents() {
    return this.events;
  }
  //----------------------------------------------------------------------------
  setData(data) {
    this.data = data;
  }

  getData() {
    return this.data;
  }
}

export { RenderJob };