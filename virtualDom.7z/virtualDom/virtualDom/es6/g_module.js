'use strict';

// debugger;
// module 管理
const $g_module = new Map();

// 系統設定
import sysConfig from './config.js';
$g_module.set('sysConfig', sysConfig);

import util from './util.js';
$g_module.set('util', util);
//-----------------------
// compile
debugger;

import { Attr } from './attr_1/index.js';
let attr = Attr.getInstance();
$g_module.set('attr', attr);

import { FactoryHandle } from './compile/factoryHandle.js'
$g_module.set('FactoryHandle', FactoryHandle);

import { TemplateManager } from './templateManager.js';
$g_module.set('TemplateManager', TemplateManager);

import { Compile } from './compile/index.js';
$g_module.set('Compile', Compile);

import { Vnode } from './vnode.js';
$g_module.set('Vnode', Vnode);

//-----------------------
// dom

import { domApi } from './modifyDom/domApi.js';
$g_module.set('domApi', domApi);

import { View } from './view/view.js'
$g_module.set('View', View);

import ModifyDom from './modifyDom/modifyDom.js';
$g_module.set('ModifyDom', ModifyDom);


import { GlobalManager } from './globalManager.js'
$g_module.set('GlobalManager', GlobalManager);


import { RenderJob } from './renderJob.js';
$g_module.set('RenderJob', RenderJob);

import { API } from './api.js';
$g_module.set('API', API);

export default $g_module;
