'use strict';

// debugger;
import $GM from './g_module.js';

let API = $GM.get('API');

export default API;

// 確定對外的命名
export { API as vtemplate };