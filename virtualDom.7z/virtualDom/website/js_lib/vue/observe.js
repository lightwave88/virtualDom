/**
 * Observer class that is attached to each observed
 * object. Once attached, the observer converts the target
 * object's property keys into getter/setters that
 * collect dependencies and dispatch updates.
 */
var Observer = function Observer(value) {
	this.value = value;
	this.dep = new Dep();
	this.vmCount = 0;
	def(value, '__ob__', this);
	if (Array.isArray(value)) {
		if (hasProto) {
			protoAugment(value, arrayMethods);
		} else {
			copyAugment(value, arrayMethods, arrayKeys);
		}
		this.observeArray(value);
	} else {
		this.walk(value);
	}
};

/**
 * Walk through all properties and convert them into
 * getter/setters. This method should only be called when
 * value type is Object.
 */
Observer.prototype.walk = function walk(obj) {
	var keys = Object.keys(obj);
	for (var i = 0; i < keys.length; i++) {
		defineReactive$$1(obj, keys[i]);
	}
};

/**
 * Observe a list of Array items.
 */
Observer.prototype.observeArray = function observeArray(items) {
	for (var i = 0, l = items.length; i < l; i++) {
		observe(items[i]);
	}
};

//==============================================================================
/**
 * Attempt to create an observer instance for a value,
 * returns the new observer if successfully observed,
 * or the existing observer if the value already has one.
 */
function observe(value, asRootData) {
	if (!isObject(value) || value instanceof VNode) {
		return
	}
	var ob;
	if (hasOwn(value, '__ob__') && value.__ob__ instanceof Observer) {
		ob = value.__ob__;
	} else if (
		shouldObserve &&
		!isServerRendering() &&
		(Array.isArray(value) || isPlainObject(value)) &&
		Object.isExtensible(value) &&
		!value._isVue
	) {
		ob = new Observer(value);
	}
	if (asRootData && ob) {
		ob.vmCount++;
	}
	return ob
}

/**
 * Define a reactive property on an Object.
 */
function defineReactive$$1(
	obj,
	key,
	val,
	customSetter,
	shallow
) {
	
	// 監聽者
	var dep = new Dep();

	var property = Object.getOwnPropertyDescriptor(obj, key);
	if (property && property.configurable === false) {
		return
	}

	// cater for pre-defined getter/setters
	var getter = property && property.get;
	var setter = property && property.set;
	if ((!getter || setter) && arguments.length === 2) {
		val = obj[key];
	}
	
	// 遞迴數據
	var childOb = !shallow && observe(val);
	//------------------
	Object.defineProperty(obj, key, {
		enumerable: true,
		configurable: true,
		get: function reactiveGetter() {
			var value = getter ? getter.call(obj) : val;
			if (Dep.target) {
				
				// 註冊接受者
				dep.depend();				
				
				if (childOb) {
					// 註冊接受者
					childOb.dep.depend();
					if (Array.isArray(value)) {
						dependArray(value);
					}
				}
			}
			return value
		},
		set: function reactiveSetter(newVal) {
			var value = getter ? getter.call(obj) : val;
			/* eslint-disable no-self-compare */
			if (newVal === value || (newVal !== newVal && value !== value)) {
				return
			}
			/* eslint-enable no-self-compare */
			if (customSetter) {
				customSetter();
			}
			// #7981: for accessor properties without setter
			if (getter && !setter) {
				return
			}
			if (setter) {
				setter.call(obj, newVal);
			} else {
				val = newVal;
			}
			childOb = !shallow && observe(newVal);
			dep.notify();
		}
	});
}
