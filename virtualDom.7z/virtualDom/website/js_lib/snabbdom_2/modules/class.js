function _updateClass(oldVnode, vnode) {
    var cur;
    var name;
    var elm = vnode.elm;

    // data.class
    var oldClass = oldVnode.data.class;
    var klass = vnode.data.class;
    if (!oldClass && !klass)
        return;
    if (oldClass === klass)
        return;
    oldClass = oldClass || {};
    klass = klass || {};

    for (name in oldClass) {
        if (oldClass[name] &&
            !Object.prototype.hasOwnProperty.call(klass, name)) {
            // was `true` and now not provided
            elm.classList.remove(name);
        }
    }
    for (name in klass) {
        cur = klass[name];
        if (cur !== oldClass[name]) {
            elm.classList[cur ? 'add' : 'remove'](name);
        }
    }
}
// 早期做法
// class:[string|[]]
function updateClassName(oldVnode, vnode) {
    const oldName = oldVnode.data.className;
    const newName = vnode.data.className;

    if (!oldName && !newName) {
        return;
    }
    if (oldName === newName) {
        return;
    }

    const elm = vnode.elm;

    if (typeof newName === 'string' && newName) {
        elm.className = newName.toString();
    } else if (isArray(newName)) {
        elm.className = '';
        newName.forEach(v => {
            elm.classList.add(v);
        });
    } else {
        // 所有不合法的值或者空值，都把 className 设为 ''
        elm.className = '';
    }
}
export const classModule = { create: updateClassName, update: updateClassName };
//# sourceMappingURL=class.js.map