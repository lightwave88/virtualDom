const $style = {};

export { $style as style };

{
  const $reg_1 = /([-]?)([0-9.]+)([a-zA-Z]*)/;

  function getNumberFormate(v) {
    let res = $reg_1.exec(v);

    if (res == null) {
      throw new TypeError(`${value} TypeError`);
    }
    let [m, negative, value, unit] = res;
    negative = negative ? -1 : 1;
    value = parseFloat(value, 10);

    return { negative, value, unit };
  };
  //----------------------------------------------------------------------------
  // 將 attrValue 做相加運算
  $style.addAttr = function (v, num) {
    let type = typeof v;
    if (type == 'object') {
      throw new TypeError(`${v} TypeError(${type})`);
    }
    let { negative, value, unit } = getNumberFormate(v);

    debugger;
    let _v = negative * value + num;

    return {
      value: _v,
      unit,
    }
  };
  //----------------------------------------------------------------------------
  // 將 attrValue 做相減運算
  $style.subtractAttr = function (v, num) {
    let type = typeof v;
    if (type == 'object') {
      throw new TypeError(`${value} TypeError(${type})`);
    }
    let { negative, value, unit } = getNumberFormate(v);

    let _v = negative * value - num;

    return {
      value: _v,
      unit,
    }
  };
  //----------------------------------------------------------------------------
  // 將 attrValue 做相除運算
  $style.dividedAttr = function (v, num) {
    let type = typeof v;
    if (type == 'object') {
      throw new TypeError(`${v} TypeError(${type})`);
    }
    let { negative, value, unit } = getNumberFormate(v);

    let _v = negative * value / num;
    return {
      value: _v,
      unit,
    };
  }
  //----------------------------------------------------------------------------
  // 將 attrValue 做相乘運算
  $style.multiplyAttr = function (v, num) {
    let type = typeof v;
    if (type == 'object') {
      throw new TypeError(`${v} TypeError(${type})`);
    }
    let { negative, value, unit } = getNumberFormate(v);

    let _v = negative * value * num;
    return {
      value: _v,
      unit,
    }
  };
}
//------------------------------------------------------------------------------
