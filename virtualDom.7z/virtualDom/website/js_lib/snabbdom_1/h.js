import { isArray, isPrimitive, flattenArray } from './utils.js';
import vnode from './vnode.js';

const hasOwnProperty = Object.prototype.hasOwnProperty
const RESERVED_PROPS = {
  key: true,
  __self: true,
  __source: true
};

export default h;
//------------------------------------------------------------------------------
function hasValidKey(config) {
  return config.key !== undefined;
}
//------------------------------------------------------------------------------
// 將 dom 行成 vnode
function h(type, config, ...children) {
  debugger;
  const props = {};

  let key = null;

  // 获取 key，填充 props 对象
  if (config != null) {

    // 重點
    if (hasValidKey(config)) {
      key = '' + config.key;
    }

    debugger;
    // 供辨識的 key
    console.log('key=(%s)', key);

    for (let propName in config) {
      debugger;
      if (hasOwnProperty.call(config, propName) && !RESERVED_PROPS[propName]) {
        props[propName] = config[propName];
      }
    }
  }
  //------------------
  let childList = flattenArray(children);

  childList = childList.map((c) => {
    // 整理文字節點

    let node;
    if (isPrimitive(c)) {
      // 是文字節點
      node = vnode(undefined, undefined, undefined, undefined, c);
    } else {
      node = c;
    }
    return node;
  });
  //------------------
  let node = vnode(type, key, props, childList);

  return node;
}
