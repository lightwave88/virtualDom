import $GM from '../../g_module.js';

// 
class TagNode extends DomNode {
  constructor(dom, parent) {
    super(dom, parent);

    this.childs = [];
    this.commandContent = [];

    // 是否檢查過 childs 的 commandArea
    this.has_checkCommandArea = false;
  }
  //-------------------------------------------
  // 在命令區塊中的 dom，受制於 data
  // not static
  checkCommandArea() {
    // debugger;
    if (this.has_checkCommandArea) {
      return;
    }
    this.has_checkCommandArea = true;
    //------------------
    let start, end;

    this.childs.forEach((el, i) => {
      if (el instanceof ScriptNode) {
        if (start == null) {
          start = i;
        }
        end = i;
      }
    });

    if (start == null) {
      return;
    }
    //------------------
    for (let i = (start + 1); i < end; i++) {
      let el = this.childs[i];
      el.setStatic(false);
    }
  }
  //-------------------------------------------
  // 取得命令內容
  // important
  _getSelfCommand() {
    // debugger;

    const dom = this.dom;
    let tagName = `"${dom.tagName}"`;
    //-----------------------
    let lines = [];

    // 開頭
    let p = $parentVarName;
    if (this.parent == null) {
      p = "null";
    }

    // 最 top 
    if (this.parent == null) {
      lines.push(`let ${$vnodeVarName} = null;\n`);
    }

    // createVnode
    lines.push(`${$vnodeVarName} = ${$createVarName}("${dom.nodeName}", ${tagName}, ${p});\n`);

    //-----------------------
    // static

    if (!this.is_static) {
      lines.push(`${$vnodeVarName}.setStatic(false);\n`);
    }
    //-----------------------
    // id

    if (dom.hasAttribute('id')) {
      let id = dom.getAttribute('id');
      lines.push(`${$vnodeVarName}.setId("${id}");\n`);
      dom.removeAttribute('id');
    }
    //-----------------------
    // class

    if (dom.hasAttribute('class')) {
      let classList = Array.from(dom.classList);
      classList = JSON.stringify(classList);

      lines.push(`${$vnodeVarName}.setClass(false, ${classList});\n`);
      dom.removeAttribute('class');
    }

    let attrName = `${$C}class`;
    if (dom.hasAttribute(attrName)) {
      // calss 有計算屬性
      let classData = dom.getAttribute(attrName);
      let v = this._ss(classData, 'class');
      lines.push(`${$vnodeVarName}.setClass(true, ${v});\n`);
      dom.removeAttribute(attrName);
    }
    //-----------------------
    // style
    if (dom.hasAttribute('style')) {
      let style = dom.getAttribute('style');

      let v = JSON.stringify(style);
      lines.push(`${$vnodeVarName}.setStyle(false, ${v});\n`);
      dom.removeAttribute('style');
    }

    attrName = `${$C}style`;
    if (dom.hasAttribute(attrName)) {
      // computer
      let style = dom.getAttribute(attrName);
      let v = this._ss(style, 'style');

      lines.push(`${$vnodeVarName}.setStyle(true, ${v});\n`);
      dom.removeAttribute(attrName);
    }
    //-----------------------
    // attr
    let attrMap = Array.from(dom.attributes);

    attrMap.forEach((attr) => {

      let key = attr.nodeName;
      let value = attr.nodeValue;

      let v;
      if ($reg_1.test(key)) {
        // 計算屬性
        v = this._ss(value, key);
        lines.push(`${$vnodeVarName}.setAttr(true, "${key}", ${v});\n`);
      } else {
        v = JSON.stringify(value);
        lines.push(`${$vnodeVarName}.setAttr(false, "${key}", ${v});\n`);
      }
    });

    lines.push(`${$vnodeVarName}.end();\n`);

    // 最 top 
    if (this.parent == null) {
      lines.push(`const ${$rootVarName} = ${$vnodeVarName};\n`);
    }

    lines.push('//-------\n');

    // format
    lines = lines.map((line) => {
      return (this._space() + line);
    });
    //-----------------------

    // child
    if (this.commandContent.length) {
      lines.push(this._space() + "{\n");
      lines.push(this._space(1) + `const ${$parentVarName} = ${$vnodeVarName};\n`);

      this.commandContent.forEach((l) => {
        lines.push(l);
      });

      lines.push(this._space() + "}\n");
    }

    let res = lines.join('');
    return res;
  }
  //-------------------------------------------
  // 清理不要的資料
  clear() {
    super.clear();
    this.has_checkCommandArea = null;
  }
}