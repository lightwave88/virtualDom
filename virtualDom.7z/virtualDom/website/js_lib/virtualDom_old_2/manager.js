import $GM from '../g_module.js';

let THE_ONE;

// 全局管理者
class Manager {
  static getInstance() {

    if(THE_ONE == null){

    }

    return THE_ONE;
  }

  constructor() {
    // id: vnode
    // id: dom.id
    this.keepAliveMap = {};
  }

  getKeepAlive(id = '') {

    if (id in this.keepAliveMap) {
      return this.keepAliveMap[id] || null;
    }
    return null;
  }
}

export { Manager };
export default Manager;