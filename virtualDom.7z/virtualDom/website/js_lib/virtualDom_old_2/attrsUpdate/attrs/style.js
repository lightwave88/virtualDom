const style = {
    attrName: 'style',
    create,
    update,
};
//------------------------------------------------------------------------------
function create(dom, vnode) {

    let style = vnode.style;

    let list = [];

    let keys = Object.keys(style);

    keys.forEach(key => {
        let value = ('' + style[key]) || '';
        list.push(`${key}:${value}`);
    });

}
//------------------------------------------------------------------------------
function update(dom, oldVnode, vnode) {
    let $style = dom.style;

    let oldKeys = Object.keys(oldVnode.style);
    let keys = Object.keys(vnode.style);
    let styleSetting = vnode.style;

    // 移除沒設定的 style
    oldKeys.forEach((k) => {
        if (k in styleSetting) {
            return;
        }
        $style.removeAttribute(k);
    });

    keys.forEach((k) => {
        let value = styleSetting[k] + '';
        $style.setAttribute(k, v);
    });
}
//------------------------------------------------------------------------------

export default style;
export { style };