const className = {
    attrName: 'class',
    create,
    update,
};
//------------------------------------------------------------------------------
function create(dom, vnode) {
    let classList = vnode.classList;

    classList.forEach(el => {
        dom.classList.add(el);
    });
}
//------------------------------------------------------------------------------
function update(dom, oldVnode, vnode) {
    // check dom
    let old_list = Array.from(dom.classList);
    let list = vnode.classList;

    if(old_list.length == 0 && list.length == 0){
        return;
    }

    old_list = new Set(old_list);
    list = new Set(list);

    old_list.forEach(el => {
        if (list.has(el)) {
            old_list.delete(el);
            list.delete(el);
        }
    });

    old_list.forEach(el => {
        dom.classList.remove(el);
    });

    list.forEach(el => {
        dom.classList.add(el);
    });
}

//------------------------------------------------------------------------------

export default className;
export { className };