import $GM from '../g_module.js';

const $modifyDom = {
  patch
};
export default $modifyDom;

let $domApi;
let $util;
let $Vnode;

(async () => {
  // 延時注入模組

  await Promise.resolve();
  debugger;

  try {
    $domApi = $GM.get('domApi');
    $util = $GM.get('util');
    $Vnode = $GM.get('Vnode');
  } catch (er) {
    console.log(er);
  }


})();
//------------------------------------------------------------------------------
function patch(oldVnode, vnode, parentDom) {
  debugger;

  const Vnode = $GM.get('Vnode');

  let dom_root;

  if (!Vnode.is_vnode(oldVnode)) {
    // 製造一個空的 vnode
    oldVnode = emptyVnode();
  }

  if (!Vnode.is_vnode(vnode)) {
    // 製造一個空的 vnode
    vnode = emptyVnode();
  }
  //------------------
  if (sameVnode(oldVnode, vnode)) {
    // 若兩個 vnode 性質相同
    // 不用重建 vnode，只要轉移 attr

    dom_root = patchNode(oldVnode, vnode);
  } else {
    // 兩個 vnode 性質差太多
    // dom 必須重建    

    let dom = oldVnode.dom || null;
    let dom_next;

    if (dom != null) {
      parentDom = dom.parentNode;
      dom_next = dom.nextSibling || null;
    }

    let new_dom = createElm(vnode);
    dom_root = new_dom;

    // 移除舊有的 domTree
    removeChildVnodes(oldVnode);

    if (new_dom != null) {
      $domApi.insertBefore(parentDom, new_dom, dom_next);
    }
  }
  return dom_root;
}
//------------------------------------------------------------------------------
function createElm(rootVnode) {
  debugger;

  if (rootVnode == null) {
    return null;
  }

  const $attrsUpdate = $GM.get('attrsUpdate');

  // 要處理的列表
  let tempList = [rootVnode];
  let parentMap = {};

  let dom;

  let i = 0;
  //-----------------------
  while (true) {
    // debugger;

    let vnode = tempList[i];
    if (vnode == null) {
      break;
    }
    let nodeName = vnode.nodeName;

    if (vnode.tagName == null) {
      // 不是 tag
      let text = vnode.text;

      switch (nodeName) {
        case '#comment':
          dom = $domApi.createComment(text);
          break;
        case '#text':
          dom = $domApi.createTextNode(text);
          break;
        default:
          throw new Error(`no deal with this domType(${nodeName})`);
          break;
      }
      vnode.setDom(dom);

      console.log('create dom(%s)', dom.nodeName);

      if (i in parentMap) {
        let parent_dom = parentMap[i];
        delete parentMap[i];
        $domApi.appendChild(parent_dom, dom);
      }

    } else {
      // tag
      dom = $domApi.createElement(vnode.tagName);
      vnode.setDom(dom);

      console.log('create dom(%s)', dom.nodeName);

      // 處理 attrs
      $attrsUpdate.create(vnode);

      if (i in parentMap) {
        let parent_dom = parentMap[i];
        delete parentMap[i];
        $domApi.appendChild(parent_dom, dom);
      }

      let childList = vnode.childs;
      if (!Array.isArray(childList)) {
        return;
      }

      childList.forEach((vnode) => {
        let j = tempList.length;
        tempList.push(vnode);
        parentMap[j] = dom;
      });

    } // endif

    i++;
  } // end while

  return rootVnode.dom;
}
//------------------------------------------------------------------------------
// oldVnode, vnode 是相同類型
// 起手式
function patchNode(oldVnode, vnode) {
  debugger;

  let rootDom = null;

  if (oldVnode.dom == null) {
    // 空節點
    return rootDom;
  }

  rootDom = oldVnode.dom;

  let sameList = [];

  sameList.push([oldVnode, vnode]);

  // 往下延伸比對 vnode tree
  let index = 0;
  //-----------------------
  while (true) {
    debugger;
    // 處理子節點
    let i = index++;
    let data = sameList[i];

    if (data == null) {
      break;
    }
    let [oldNode, node] = data;

    let dom = oldNode.dom;

    console.log('patchNode...');
    console.dir(dom);
    console.log('--------------');

    let tempList = _findSameChildVnode(oldNode, node);

    tempList.forEach((d) => {
      sameList.push(d);
    });
  }
  //-----------------------
  debugger;
  const $attrsUpdate = $GM.get('attrsUpdate');

  // 處理 attrs 轉換
  sameList.forEach((data) => {
    let [oldNode, node] = data;
    let dom = oldNode.dom;
    console.log('-----------\n');
    console.log('update dom(%s)', dom.nodeName);
    console.dir(oldNode.dom);
    console.log('-----------\n');

    node.setDom(dom);

    if (dom.tagName != null) {
      // 標籤 dom
      $attrsUpdate.update(oldNode, node);
    } else {
      // 非標籤 dom
      if (node.text.localeCompare(oldNode.text) != 0) {
        $domApi.setTextContent(dom, node.text);
      }
    }

  });

  return rootDom;
}
//------------------------------------------------------------------------------

// 這邊可以進化
function _findSameChildVnode(oldVnode, vnode) {
  let sameList = [];

  // oldVnode 一定有相對應的 dom
  let parent_dom = oldVnode.dom;

  let oldList = oldVnode.childs;
  let list = vnode.childs;

  let length = (oldList.length > list.length ? oldList.length : list.length);

  for (let i = 0; i < length; i++) {

    let oldVnode = oldList[i] || null;
    let vnode = list[i] || null;

    if (oldVnode == null) {

      let dom = createElm(vnode);
      $domApi.appendChild(parent_dom, dom);
      continue;
    }

    if (vnode == null) {
      let dom = oldVnode.dom;
      $domApi.removeChild(parent_dom, dom);
      continue;
    }

    // 這邊可以進化
    if (sameVnode(oldVnode, vnode)) {
      sameList.push([oldVnode, vnode]);
      continue;
    } else {
      // 不同格式的子節點

      let dom = oldVnode.dom;
      let dom_next = dom.nextSibling || null;

      let new_dom = createElm(vnode);

      removeChildVnodes(oldVnode);

      if (new_dom != null) {
        $domApi.insertBefore(parent_dom, new_dom, dom_next);
      }
    }

  } // endfor

  return sameList;
}
//------------------------------------------------------------------------------

function emptyVnode() {
  return $Vnode.getInstance();
}
//------------------------------------------------------------------------------
// 比較兩個 vnode 性質是否相同
function sameVnode(a, b) {
  debugger;

  const a_attrs = a.attrs;
  const b_attrs = b.attrs;

  // dom.type 不同就視爲不同
  // dom 必須重建 不然可能有問題
  // <input> 尤其嚴重
  let a_type = (a_attrs.has('type') ? a_attrs.get('type') : null);
  let b_type = (b_attrs.has('type') ? b_attrs.get('type') : null);

  if (a_type !== b_type) {
    return false;
  }
  // 比較 nodeName
  if (a.nodeName !== b.nodeName) {
    return false;
  }

  // 比較 dom.id
  if (a.id !== b.id) {
    return false;
  }

  // 比較 dom.class
  // if (a.classList.length != b.classList.length) {
  //   return false;
  // }

  // if (a.classString != b.classString) {
  //   return false;
  // }

  return true;
}
//------------------------------------------------------------------------------

function removeChildVnodes(vnodes = []) {
  debugger;

  if (vnodes == null) {
    return;
  }

  if (!Array.isArray(vnodes)) {
    vnodes = [vnodes];
  }

  let tempList = [];

  vnodes.forEach(v => {
    // 先脫鉤第一層 dom

    tempList.push(v);

    // 有可能碰到 空 vnode
    let dom = v.dom || null;

    if (dom == null) {
      return;
    }

    let parent = dom.parentNode;

    if (parent != null) {
      $domApi.removeChild(parent, dom);
    }
  });

  $util.nextStep(() => {
    clearVnodeTree(tempList);
  });

}
//------------------------------------------------------------------------------

// 移除 dom 並清除以下的 vnode
// 釋放不用的記憶體
function removeChildDoms(doms = []) {

  if (doms == null) {
    return;
  }

  if (!Array.isArray(doms)) {
    doms = [doms];
  }

  let tempList = [];

  doms.forEach(d => {
    let vnode = $Vnode.getVnodeByDom(d);
    let parent = d.parentNode;
    if (parent) {
      // 先脫鉤第一層 dom
      $domApi.removeChild(parent, d);
    }
    if (vnode != null) {
      tempList.push(vnode);
    }
  });

  if (!tempList.length) {
    return;
  }

  $util.nextStep(() => {
    clearVnodeTree(tempList);
  });
}
//------------------------------------------------------------------------------

function clearVnodeTree(list) {
  let index = 0;
  while (true) {
    debugger;
    let i = index++;

    let vnode = list[i];
    if (vnode == null) {
      break;
    }
    // destroy vnode 
    vnode.destroy();

    let childs = vnode.childs;

    childs.forEach((child) => {
      list.push(child);
    });
  } // endwhile

}