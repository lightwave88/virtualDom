import $GM from '../g_module.js';
import TemplateManager from './templateManager.js';

// 針對 controller 綁定 
// 從 controller 取得設定資訊
class TemplateManagerWithController extends TemplateManager {

  static getInstance(options) {
    let ins = new TemplateManagerWithController(options);
    ins.init();
    return ins;
  }

  constructor(options = {}) {
    super(options);
    this.controller = null;
  }

  init(options) {
    let { controller } = this.options;
    this.controller = controller;
    this.executeContext = controller;

  }
}

export { TemplateManagerWithController };
export default TemplateManagerWithController;