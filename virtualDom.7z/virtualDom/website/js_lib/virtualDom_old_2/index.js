debugger;
import $GM from './g_module.js';

let api = $GM.get('api');

export default api;

// 確定對外的命名
export { api as vtemplate };